// Authors: Ryan Chen
// California State University, Fullertion
// CPSC 362 Summer Session A
// This file is a configuration file for the chat bot controller
// It defines the acceptable commands and allows the chat bot
// to log in and interface with the Discord client
// Date Created: 6/19/2019
// Last modified: 6/22/2019

export let config = 
{
    "token": "NTg5OTEwMDI0MjQ4MjI5OTYz.XQal0g.5z6jPn9rt6xUuo_Hf_g7iZfHaIQ",
    "prefix": "!",
    "commands": [   
                    "help",
                    "remind",
                    "subscribe",
                    "question",
                    "poll",
                    "endpoll",
                    "vote"
                ]
}