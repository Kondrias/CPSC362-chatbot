import * as Discord from "discord.js";
import {IBotCommand} from "../api";

export default class vote implements IBotCommand
{
    private readonly _command = "vote";

    help(): string {
        return "This command outputs the user manual";
    } 

    isCommand(command: string): boolean {
        return command === this._command;
    }

    runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): void {
        try
        {
            msgObject.delete(); //deletes user's message for privacy purposes
        }
        catch (exception)
        {
            console.log(exception);
        }

        let voteoption = "";
        if (parseInt(args[0]) === 1)
        {
            voteoption = "C";
        }
        else if (parseInt(args[0]) === 2)
        {
            voteoption = "E";
        }
        else
        {
            msgObject.channel.send(msgObject.author + ", that is an invalid vote option. Please use either !vote 1 or !vote 2");
            return;
        }

        //code to update poll data from google sheets
        const fs = require('fs');
        const readline = require('readline');
        const {google} = require('googleapis');
        const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];
        const TOKEN_PATH = 'token.json';

        // Load client secrets from a local file.
        fs.readFile('credentials.json', (err: any, content: any) => {
        if (err) return console.log('Error loading client secret file:', err);
        // Authorize a client with credentials, then call the Google Sheets API.
        authorize(JSON.parse(content), updatePoll);
        });

        /**
         * Create an OAuth2 client with the given credentials, and then execute the
         * given callback function.
         * @param {Object} credentials The authorization client credentials.
         * @param {function} callback The callback to call with the authorized client.
         */
        function authorize(credentials: any, callback: any) {
            const {client_secret, client_id, redirect_uris} = credentials.installed;
            const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

            // Check if we have previously stored a token.
            fs.readFile(TOKEN_PATH, (err: any, token: any) => {
                if (err) return getNewToken(oAuth2Client, callback);
                oAuth2Client.setCredentials(JSON.parse(token));
                callback(oAuth2Client);
            });
        }

        /**
         * Get and store new token after prompting for user authorization, and then
         * execute the given callback with the authorized OAuth2 client.
         * @param {google.auth.OAuth2} oAuth2Client The OAuth2 client to get token for.
         * @param {getEventsCallback} callback The callback for the authorized client.
         */
        function getNewToken(oAuth2Client: any, callback: any) {
            const authUrl = oAuth2Client.generateAuthUrl({
                access_type: 'offline',
                scope: SCOPES,
            });
            console.log('Authorize this app by visiting this url:', authUrl);
            const rl = readline.createInterface({
                input: process.stdin,
                output: process.stdout,
            });
            rl.question('Enter the code from that page here: ', (code: any) => {
                rl.close();
                oAuth2Client.getToken(code, (err: any, token: any) => {
                if (err) return console.error('Error while trying to retrieve access token', err);
                oAuth2Client.setCredentials(token);
                // Store the token to disk for later program executions
                fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err: any) => {
                    if (err) return console.error(err);
                    console.log('Token stored to', TOKEN_PATH);
                });
                callback(oAuth2Client);
                });
            });
        }

        //Updates the number of votes in the current poll spreadsheet
        function updatePoll(auth: any) {
            let embed = new Discord.RichEmbed();
            const sheets = google.sheets({version: 'v4', auth});
            sheets.spreadsheets.values.get({
                spreadsheetId: '17mt-zfZQbm6YLBwhDff25e8lj2gLCglczQcM-iG8WXk',
                range: `Current Poll!${voteoption}2:${voteoption}2`, //get cell that corresponds to count of vote option
            }, (err: any, res: any) => {
                if (err) return console.log('The API returned an error: ' + err);
                const rows = res.data.values;
                if (rows === undefined) //check if data exists. Poll must provide 0 under the votes in order to work
                {
                    msgObject.channel.send(msgObject.author + "There is no ongoing poll.");
                    return;
                }
                if (rows.length) {
                    rows.map((row: any) => {
                        let updatevote = parseInt(row[0]) + 1 + "";
                        //add poll data to Polls spreadsheet to archive
                        var values = [[`${updatevote}`],];
                        var body = {
                            values: values
                        };
                        sheets.spreadsheets.values.update({
                            spreadsheetId: '17mt-zfZQbm6YLBwhDff25e8lj2gLCglczQcM-iG8WXk',
                            range: `Current Poll!${voteoption}2:${voteoption}2`,
                            valueInputOption: 'RAW',
                            resource: body
                        }).then((response: any) => {
                            msgObject.channel.send(msgObject.author + ", Your vote has been added!");
                        });
                    });
                } else {
                    msgObject.channel.send('No data found.');
                }
            });
        }
    }
}