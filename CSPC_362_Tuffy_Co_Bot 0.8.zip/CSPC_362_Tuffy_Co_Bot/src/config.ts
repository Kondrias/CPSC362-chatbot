export let config = 
{
    "token": "NTg5OTEwMDI0MjQ4MjI5OTYz.XQal0g.5z6jPn9rt6xUuo_Hf_g7iZfHaIQ",
    "prefix": "!",
    "commands": [   
                    "help",
                    "remind",
                    "subscribe",
                    "question",
                    "poll"
                ]
}