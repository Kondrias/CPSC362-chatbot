// Authors: Ryan Chen
// California State University, Fullertion
// CPSC 362 Summer Session A
// Class: subscribe
// This class defines the command for subscribe. It allows users
// to add their email to the emailing list stored in Google Sheets.
// It will also send a confirmation email on subscription.
// Date Created: 6/19/2019
// Last modified: 6/22/2019

import * as Discord from "discord.js";
import {IBotCommand} from "../api";

export default class subscribe implements IBotCommand
{
    private readonly _command = "subscribe";

    help(): string {
        let content = "This command subscribes an email to our emailing list." + '\n' +
                        "local.address@domain.name is the email address you wish to subscribe." + '\n' +
                        "This command will also send a confirmation email.";
        return content;
    } 

    isCommand(command: string): boolean {
        return command === this._command;
    }

    runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): void {
        try
        {
            msgObject.delete(); //deletes user's message for privacy purposes
        }
        catch (exception)
        {
            console.log(exception);
        }
           
        if (args.length === 1 && this.isValidEmail(args[0]))
        {
            //Code for appending values onto google sheets
            const fs = require('fs');
            const readline = require('readline');
            const {google} = require('googleapis');
            const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];
            const TOKEN_PATH = 'token.json';

            // Load client secrets from a local file.
            fs.readFile('credentials.json', (err: any, content: any) => {
                if (err) return console.log('Error loading client secret file:', err);
                // Authorize a client with credentials, then call the Google Sheets API.
                authorize(JSON.parse(content), storeEmail); 
            });

            /**
             * Create an OAuth2 client with the given credentials, and then execute the
             * given callback function.
             *  @param {Object} credentials The authorization client credentials.
             *  @param {function} callback The callback to call with the authorized client.
             */
            function authorize(credentials: any, callback: any) {
                const {client_secret, client_id, redirect_uris} = credentials.installed;
                const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

            // Check if we have previously stored a token.
                fs.readFile(TOKEN_PATH, (err: any, token: any) => {
                    if (err) return getNewToken(oAuth2Client, callback);
                    oAuth2Client.setCredentials(JSON.parse(token));
                    callback(oAuth2Client);
                });
            }

            /**
             * Get and store new token after prompting for user authorization, and then
             * execute the given callback with the authorized OAuth2 client.
             *  @param {google.auth.OAuth2} oAuth2Client The OAuth2 client to get token for.
             *  @param {getEventsCallback} callback The callback for the authorized client.
             */
            function getNewToken(oAuth2Client: any, callback: any) {
                const authUrl = oAuth2Client.generateAuthUrl({
                    access_type: 'offline',
                    scope: SCOPES,
                });
                console.log('Authorize this app by visiting this url:', authUrl);
                const rl = readline.createInterface({
                    input: process.stdin,
                    output: process.stdout,
                });
                rl.question('Enter the code from that page here: ', (code: any) => {
                    rl.close();
                    oAuth2Client.getToken(code, (err: any, token: any) => {
                        if (err) return console.error('Error while trying to retrieve access token', err);
                        oAuth2Client.setCredentials(token);
                        // Store the token to disk for later program executions
                        fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err: any) => {
                            if (err) return console.error(err);
                            console.log('Token stored to', TOKEN_PATH);
                        });
                        callback(oAuth2Client);
                    });
                });
            }

            /**
             * Store username and email input onto spreadsheet
             * @see https://docs.google.com/spreadsheets/d/17mt-zfZQbm6YLBwhDff25e8lj2gLCglczQcM-iG8WXk/edit
             * @param {google.auth.OAuth2} auth The authenticated Google OAuth client.
             */
            function storeEmail(auth: any) {
                const sheets = google.sheets({version: 'v4', auth});
                var values = [[`${msgObject.author.username}`, `${args[0]}`],]; //input data
                var body = {values: values};

                sheets.spreadsheets.values.append({
                    spreadsheetId: '17mt-zfZQbm6YLBwhDff25e8lj2gLCglczQcM-iG8WXk',
                    range: 'Emailing List!A2:B',//range: 'SheetName!StartRange:EndRange
                    valueInputOption: 'RAW',
                    resource: body
                }).then((response: any) => {
                    //Code for sending email
                    var nodemailer = require('nodemailer');
                    var transporter = nodemailer.createTransport({
                        service: 'gmail',
                        auth: {
                            user: 'rcbotemail@gmail.com',
                            pass: 'CowsGoMoo'
                        }
                    });
                    var mailOptions = {
                        from: 'rcbotemail@gmail.com',
                        to: `${args[0]}`,
                        subject: 'CSPC 362 Tuffy Co. Bot Subscription',
                        text: `Congratulations ${msgObject.author.username}! You have subscribed to my emailing list! You can't unsubscribe yet, but I wont spam you. :)`
                    };
                    transporter.sendMail(mailOptions, function(error: any, info: any){
                        if (error) {
                            console.log(error);
                        } else {
                            msgObject.author.send(`I sent you an email`);
                        }
                    });

                    msgObject.channel.send(msgObject.author + ` subscribed to our emailing list!`);
                });
            }  
        }
        else
        {
            if (args.length === 0) 
            {
                msgObject.channel.send(msgObject.author + ", please enter a valid email address.");
            }
            else
            {
                msgObject.channel.send(msgObject.author + ", that is not a valid email address.");
            }
        }
    }

    //email: localAddress@domainName
    //Checks if email is valid
    isValidEmail(email: string): boolean {
        //split email into local address portion and domain name portion
        let localdomain = email.split("@");
        if (!(localdomain.length === 2)) {return false;} //must contain exactly 1 @ character
        if(!(/^[a-zA-Z0-9._-]/.test(localdomain[0]))) {return false;} //if local only contains accepted characters
        if(/0-9._-/.test(localdomain[0].charAt(0))) {return false;} //if local does not start with ._- or number
        if(!(/^[a-zA-Z0-9.-]/.test(localdomain[1]))) {return false;} //if domain only contains accepted characters
        if(/-/.test(localdomain[1].charAt(0))) {return false;} //if domain does not start with -
        if(/-/.test(localdomain[1].charAt(localdomain[1].length - 1))) {return false;} //if domain does not end with -
        return true;
    }
}

