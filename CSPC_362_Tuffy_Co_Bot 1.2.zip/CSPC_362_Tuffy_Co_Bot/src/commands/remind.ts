// Authors: Ryan Chen
// California State University, Fullertion
// CPSC 362 Summer Session A
// Class: remind
// This class defines the remind command. It allows users to set a reminder
// at a given time with their own personalized message.
// Date Created: 6/19/2019
// Last modified: 6/22/2019

import * as Discord from "discord.js";
import * as Cron from "node-cron";
import {IBotCommand} from "../api";

export default class remind implements IBotCommand
{
    private readonly _command = "remind";

    help(): string {
        let content = "This command sets a reminder to be sent at a given time in the UTC-8 time zone." +'\n' +
                        "The argument HH:MM is the 24-hour time notation of the time that the reminder should be sent at." + '\n' +
                        "HH is the hours. The acceptable range is 00 - 23" + '\n' +
                        "MM is the minutes. The acceptable range is 00 - 59"  + '\n' +
                        "The argument <message> is the content of the reminder."  + '\n' +
                        "<message> has no length limit.";
        return content;
    } 

    isCommand(command: string): boolean {
        return command === this._command;
    }

    runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): void {
        try
        {
            msgObject.delete(); //deletes user's message for privacy purposes
        }
        catch (exception)
        {
            console.log(exception);
        }

        if (args.length > 0 && this.isValidTime(args[0])) //check if time input is valid
        {
            //breaks time argument into hourminute[0] for hours and hourminute[1] for minutes
            let hourminute = args[0].split(":"); 
            msgObject.channel.send(msgObject.author + `, I set a reminder for ${hourminute[0]}:${hourminute[1]}`);
    
            //Create reminder message from remaining arguments
            let reminderMessage = "Reminder: ";
            let i;
            for (i = 1; i < args.length; i++)
            {
                reminderMessage += args[i] + " ";
            }

            //node-cron job to schedule the reminder. Deletes task after execution.
            let time = `${hourminute[1]} ${hourminute[0]} * * *`;
            let reminder = Cron.schedule(time, ()=> {
                msgObject.author.send(`${reminderMessage}`);
                reminder.destroy();
            });
        }
        else
        {
            msgObject.channel.send(msgObject.author + `, your value for time (${args[0]}) is invalid. Type !help for the User Manual`);
        }
    }
    //Checks if time argument is valid
    isValidTime(time: string): boolean {
        if (time.length < 3 || time.length > 5) {return false;} //should only be at least 3 and at most 5 characters long
        if (!(time.includes(":"))) {return false;} //must have a ':' separator

        //breaks time argument into hourminute[0] for hours and hourminute[1] for minutes
        let hourminute = time.split(":");
        if (!(hourminute.length === 2)) {return false;} //too many values to be a time

        if(!(/^\d+$/.test(hourminute[0]))) {return false;} //hours value is not a number
        if(!(/^\d+$/.test(hourminute[1]))) {return false;} //minutes value is not a number

        if (parseInt(hourminute[0]) < 0 || parseInt(hourminute[0]) > 23) {return false;} //hours value out of bounds
        if (parseInt(hourminute[1]) < 0 || parseInt(hourminute[1]) > 59) {return false;} //minutes value out of bounds

        //is valid time if passes all error checks
        return true;
    }
}