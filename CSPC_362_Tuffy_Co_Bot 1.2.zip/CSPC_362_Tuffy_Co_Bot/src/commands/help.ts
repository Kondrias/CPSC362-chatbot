// Authors: Ryan Chen
// California State University, Fullertion
// CPSC 362 Summer Session A
// Class: help
// This class defines the help command. It is responsible for running
// the user manual for the bot and gives details on the commands
// and parameters needed.
// Date Created: 6/19/2019
// Last modified: 6/22/2019

import * as Discord from "discord.js";
import {IBotCommand} from "../api";
import remind from "./remind";
import question from "./question";
import subscribe from "./subscribe";
import poll from "./poll";
import vote from "./vote";
import endpoll from "./endpoll";

export default class help implements IBotCommand
{
    private readonly _command = "help";

    help(): string {
        let content = "This command displays the user manual." + '\n' +
                        "The argument command should be one of the following words:" + '\n' +
                        "help, remind, question, subscribe, poll, vote, endpoll" + '\n' +
                        "This will bring up a detailed manual on the specified command" + '\n' +
                        "With no command argument, !help will display the User Manual";
        return content;
    } 

    isCommand(command: string): boolean {
        return command === this._command;
    }

    runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): void {
        let embed = new Discord.RichEmbed();
        if(args[0] === "help")
        {
            let command =  new help();
            let content = command.help();
            embed.setTitle("!help Manual");
            embed.addField("!help command", content);
            msgObject.channel.send(embed);
        }        
        else if(args[0] === "remind")
        {
            let command =  new remind();
            let content = command.help();
            embed.setTitle("!remind Manual");
            embed.addField("!remind HH:MM <Message...>", content);
            msgObject.channel.send(embed);
        }        
        else if(args[0] === "question")
        {
            let command =  new question();
            let content = command.help();
            embed.setTitle("!question Manual");
            embed.addField("!question <Question...>", content);
            msgObject.channel.send(embed);
        }        
        else if(args[0] === "subscribe")
        {
            let command =  new subscribe();
            let content = command.help();
            embed.setTitle("!subscribe Manual");
            embed.addField("!subscribe local.address@domain.name", content);
            msgObject.channel.send(embed);
        }        
        else if(args[0] === "poll")
        {
            let command =  new poll();
            let content = command.help();
            embed.setTitle("!poll Manual");
            embed.addField("!poll", content);
            msgObject.channel.send(embed);
        }        
        else if(args[0] === "vote")
        {
            let command =  new vote();
            let content = command.help();
            embed.setTitle("!vote Manual");
            embed.addField("!vote X", content);
            msgObject.channel.send(embed);
        }        
        else if(args[0] === "endpoll")
        {
            let command =  new endpoll();
            let content = command.help();
            embed.setTitle("!endpoll Manual");
            embed.addField("!endpoll", content);
            msgObject.channel.send(embed);
        }
        else //Default Manual
        {
            embed.setTitle("User Manual:");
            embed.addField("!help", "This command brings up the user manual" 
                            + '\n' + `Use "!help help" for more details.`);
            embed.addField("!remind", "This command lets you set a reminder" 
                            + '\n' + `Use "!help remind" for more details.`);
            embed.addField("!question", "This command shows you the FAQs and lets you store a question" 
                            + '\n' + `Use "!help question" for more details.`);
            embed.addField("!subscribe", "This command subscribes you to our mailing list" 
                            + '\n' + `Use "!help subscribe" for more details.`);
            embed.addField("!poll", "This command announces the current poll" 
                            + '\n' + `Use "!help poll" for more details.`);
            embed.addField("!vote", "This command lets you vote in the poll" 
                            + '\n' + `Use "!help vote" for more details.`);
            embed.addField("!endpoll", "This command announces the poll results and ends it" 
                            + '\n' + `Use "!help endpoll" for more details.`);
            msgObject.channel.send(embed);
        }
    }
}