// Authors: Ryan Chen
// California State University, Fullertion
// CPSC 362 Summer Session A
// Module: Command Interface
// This interface is for the various commands. It defines the basic functionalities
// and requirements of each command.
// Date Created: 6/16/2019
// Last modified: 6/22/2019

import * as Discord from "discord.js";

export interface IBotCommand
{
    help(): string;
    isCommand(command: string): boolean;
    runCommand(args: string[], msgObject: Discord.Message, client: Discord.Client): void;
}